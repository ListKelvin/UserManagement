export interface UserType {
  id: string;
  username: string;
  email: string;
  birthdate: string;
}
